﻿namespace EmyProject.CustomService.Model
{
    public class ConvertModel
    {
        public double Start { get; set; }
        public double End { get; set; }
        public double RealEnd { get; set; }
        public double ExtraTime { get; set; }
    }
}
