﻿namespace EmyProject.CustomService.Model
{
    public class PathModel
    {
        public string Path { get; set; }
    }
}
